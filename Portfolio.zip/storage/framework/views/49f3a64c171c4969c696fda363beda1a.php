<div class="mt-52 tracking-wider">
    <p class="text-3xl font-light text-green-900 dark:text-green-400">Hi! Nice to meet you.</p>
    <h1 class="text-5xl sm1:text-6xl dark:text-slate-300">My name is Meil, and I build website.</h1>
    <p class="text-2xl font-light dark:font-thin mt-5">I am a web developer that has experience building websites <br/> using industry-leading technologies. At present, <br/> I am working to improve my skills in developing <br/> single-page applications using <br/> React and Laravel.  </p>
    
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/portfolio/resources/views/components/Intro.blade.php ENDPATH**/ ?>