<div class='text-2xl black:text-slate-300 position: fixed mt-72 ml-3 hidden lg1:block'>
    <a href='https://github.com/Meil1994' target='blank'><i class="fa-brands fa-github mb-5 mt-7 hover:text-green-900 dark:hover:text-green-300'"></i></a>
   <br/>
    <a href='https://www.facebook.com/profile.php?id=100081302417501' target='blank'><i class="fa-brands fa-facebook mb-5 hover:text-green-900 dark:hover:text-green-300'"></i></a>
    <br/>
    <a href='https://www.linkedin.com/in/meilchu-cabaluna-003163256' target='blank'><i class="fa-brands fa-linkedin mb-5 hover:text-green-900 dark:hover:text-green-300"></i></a>
    <div class="border-l border-black dark:border-slate-300 h-60 ml-2"></div> 

</div>